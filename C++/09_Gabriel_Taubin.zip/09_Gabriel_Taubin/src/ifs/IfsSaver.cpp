// AUTHOR : Your Name <your_email@brown.edu>
//
// IfsSaver.cpp
//

#include "IfsSaver.hpp"

bool IfsSaver::save(const char* filename, Ifs& ifs) {
  bool success = false;
  if(filename!=(const char*)0) {
    // TODO
  }
  return success;
}

void IfsSaver::registerSaver(Saver* saver) {
  if(saver!=(Saver*)0) {
    // TODO
  }
}
