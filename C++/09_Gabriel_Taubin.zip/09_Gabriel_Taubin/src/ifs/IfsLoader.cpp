// AUTHOR : Your Name <your_email@brown.edu>
//
// IfsLoader
//

#include "IfsLoader.hpp"

bool IfsLoader::load(const char* filename, Ifs& ifs) {
  bool success = false;
  if(filename!=(const char*)0) {
    // TODO
  }
  return success;
}

void IfsLoader::registerLoader(Loader* loader) {
  if(loader!=(Loader*)0) {
    // TODO
  }
}
