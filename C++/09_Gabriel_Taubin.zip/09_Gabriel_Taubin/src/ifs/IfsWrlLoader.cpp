// AUTHOR : Your Name <your_email@brown.edu>
//
// IfsLoader.cpp
//

#include "IfsWrlLoader.hpp"

#define VRML_HEADER "#VRML V2.0 utf8"

const char* IfsWrlLoader::_ext = "wrl";

bool IfsWrlLoader::load(const char* filename, Ifs& ifs) {
  bool success = false;

  if(filename!=(char*)0) {
    // TODO
  }

  return success;
}

