// AUTHOR : Your Name <your_email@brown.edu>
//
// Ifs.cpp
//

#include "Ifs.hpp"
#include <iostream>

// VRML'97
//
// IndexedFaceSet {
//   eventIn       MFInt32 set_colorIndex
//   eventIn       MFInt32 set_coordIndex
//   eventIn       MFInt32 set_normalIndex
//   eventIn       MFInt32 set_texCoordIndex
//   exposedField  SFNode  color             NULL
//   exposedField  SFNode  coord             NULL
//   exposedField  SFNode  normal            NULL
//   exposedField  SFNode  texCoord          NULL
//   field         SFBool  ccw               TRUE
//   field         MFInt32 colorIndex        []        # [-1,)
//   field         SFBool  colorPerVertex    TRUE
//   field         SFBool  convex            TRUE
//   field         MFInt32 coordIndex        []        # [-1,)
//   field         SFFloat creaseAngle       0         # [ 0,)
//   field         MFInt32 normalIndex       []        # [-1,)
//   field         SFBool  normalPerVertex   TRUE
//   field         SFBool  solid             TRUE
//   field         MFInt32 texCoordIndex     []        # [-1,)
// }

Ifs::Ifs() {
/* remember to properly initialize all the class variables which do
   not have a default constructor */
}

Ifs::~Ifs() {
  // TBD
}

void           Ifs::clear() { /* TODO */ }
bool&          Ifs::getCcw() { /* TODO */ }
bool&          Ifs::getConvex() { /* TODO */ }
float&         Ifs::getCreaseangle() { /* TODO */ }
bool&          Ifs::getSolid() { /* TODO */ }
bool&          Ifs::getNormalPerVertex() { /* TODO */ }
bool&          Ifs::getColorPerVertex() { /* TODO */ }
vector<float>& Ifs::getCoord() { /* TODO */ }
vector<int>&   Ifs::getCoordIndex() { /* TODO */ }
vector<float>& Ifs::getNormal() { /* TODO */ }
vector<int>&   Ifs::getNormalIndex() { /* TODO */ }
vector<float>& Ifs::getColor() { /* TODO */ }
vector<int>&   Ifs::getColorIndex() { /* TODO */ }
vector<float>& Ifs::getTexCoord() { /* TODO */ }
vector<int>&   Ifs::getTexCoordIndex() { /* TODO */ }
int            Ifs::getNumberOfFaces() { 0; /* TODO */ }
int            Ifs::getNumberOfCorners() { 0; /* TODO */ }
int            Ifs::getNumberOfCoord() { 0; /* TODO */ }
int            Ifs::getNumberOfNormal() { 0; /* TODO */ }
int            Ifs::getNumberOfColor() { 0; /* TODO */ }
int            Ifs::getNumberOfTexCoord() { 0; /* TODO */ }
void           Ifs::setNormalPerVertex(bool value) { /* TODO */ }
void           Ifs::setColorPerVertex(bool value) { /* TODO */ }

// TODO  
Ifs::Binding Ifs::getNormalBinding() {
  // if(normal.size()==0)
  //   NO_NORMALS
  // else if(normalPerVertex==FALSE)
  //   if(normalIndex.size()>0)
  //     NORMAL_PER_FACE_INDEXED;
  //     assert(normalIndex.size()==getNumberOfFaces())
  //   else
  //     NORMAL_PER_FACE;
  //     assert(normal.size()/3==getNumberOfFaces())
  // else // if(normalPerVertex==TRUE)
  //   if(normalIndex.size()>0)
  //     NORMAL_PER_CORNER;
  //     assert(normalIndex.size()==coordIndex.size())
  //   else
  //     NORMAL_PER_VERTEX;
  //     assert(normal.size()/3==coord.size()/3)
  return PB_NONE;
}

// TODO  
Ifs::Binding Ifs::getColorBinding() {
  // if(color.size()==0)
  //   NO_COLORS
  // else if(colorPerVertex==FALSE)
  //   if(colorIndex.size()>0)
  //     COLOR_PER_FACE_INDEXED;
  //     assert(colorIndex.size()==getNumberOfFaces())
  //   else
  //     COLOR_PER_FACE;
  //     assert(color.size()/3==getNumberOfFaces())
  // else // if(colorPerVertex==TRUE)
  //   if(colorIndex.size()>0)
  //     COLOR_PER_CORNER;
  //     assert(colorIndex.size()==coordIndex.size())
  //   else
  //     COLOR_PER_VERTEX;
  //     assert(color.size()/3==coord.size()/3)
  return PB_NONE;
}

// TODO  
Ifs::Binding Ifs::getTexCoordBinding() {
  // if(texCoord.size()==0)
  //   NO_TEX_COORD
  // else if(texCoordIndex.size()>0)
  //   TEX_COORD_PER_CORNER;
  //   assert(texCoordIndex.size()==coordIndex.size())
  // else
  //   TEX_COORD_PER_VERTEX;
  //   assert(texCoord.size()/3==coord.size()/3)
  return PB_NONE;
}

