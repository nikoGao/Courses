// AUTHOR : Your Name <your_email@brown.edu>
//
// IfsWrlSaver.cpp
//

#include "IfsWrlSaver.hpp"

const char* IfsWrlSaver::_ext = "wrl";

bool IfsWrlSaver::save(const char* filename, Ifs& ifs) {
  bool success = false;
  if(filename!=(char*)0) {
    // TODO
  }
  return success;
}

