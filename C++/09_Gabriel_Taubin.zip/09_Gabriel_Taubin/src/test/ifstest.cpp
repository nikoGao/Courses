// AUTHOR : Your Name <your_email@brown.edu>
//
// ifstest.cpp
//

#include <string>
#include <iostream>

using namespace std;

#include <ifs/Ifs.hpp>
#include <ifs/IfsLoader.hpp>
#include <ifs/IfsSaver.hpp>
#include <ifs/IfsWrlLoader.hpp>
#include <ifs/IfsWrlSaver.hpp>

class Data {
public:
  bool   debug;
  bool   removeNormal;
  bool   removeColor;
  bool   removeTexCoord;
  string inFile;
  string outFile;
public:
  Data():
    debug(false),
    removeNormal(false),
    removeColor(false),
    removeTexCoord(false),
    inFile(""),
    outFile("") {
  }
};

const char* tv(bool value)        { return (value)?"true":"false";                 }

void options(Data& D) {
  cerr << "   -d|-debug               [" << tv(D.debug)          << "]" << endl;
  cerr << "  -rn|-removeNormal        [" << tv(D.removeNormal)   << "]" << endl;
  cerr << "  -rc|-removeColor         [" << tv(D.removeColor)    << "]" << endl;
  cerr << "  -rt|-removeTexCoord      [" << tv(D.removeTexCoord) << "]" << endl;
}

void usage(Data& D) {
  cerr << "USAGE: ifstest [options] inFile outFile" << endl;
  cerr << "   -h|-help" << endl;
  options(D);
  cerr << endl;
  exit(0);
}

void error(const char *msg) {
  cerr << "ERROR: ifstest | " << ((msg)?msg:"") << endl;
  exit(0);
}

//////////////////////////////////////////////////////////////////////
int main(int argc, char **argv) {

  Data D;

  if(argc==1) usage(D);

  for(int i=1;i<argc;i++) {
    /* TODO */
  }

  if(D.inFile =="") error("no inFile");
  if(D.outFile=="") error("no outFile");

  // if command run without arguments, print the usage message and exit

  // if errors are detected in the argument list, print an error
  // message and exit

  bool success = false;

  //////////////////////////////////////////////////////////////////////
  // create loader and saver and register IfsLoaders and IfsSavers

  // TODO

  //////////////////////////////////////////////////////////////////////
  // open input file and load Ifs

  Ifs ifs;

  // TODO

  // remember to set success to true or false

  if(D.debug) {
    // PRINT SOME INFO ABOUT IFS OR ERROR MESSAGE
  }

  if(success==false) return -1;

  //////////////////////////////////////////////////////////////////////
  // process

  if(D.removeNormal) {
    // TODO
  }
  if(D.removeColor) {
    // TODO
  }
  if(D.removeTexCoord) {
    // TODO
  }

  //////////////////////////////////////////////////////////////////////
  // save modified Ifs to output file

  // TODO

  if(D.debug) {
    // PRINT SOME INFO ABOUT SAVED IFS OR ERROR MESSAGE
  }

  //////////////////////////////////////////////////////////////////////

  return 0;
}
