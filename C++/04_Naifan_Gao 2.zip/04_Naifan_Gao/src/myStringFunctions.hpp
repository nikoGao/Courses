#ifndef functions_h_
#define functions_h_
#include <string.h>
#include <iostream>
using namespace std;

extern char * concat(const char*, const char*);
extern bool substr(const char*, const char*, unsigned&);
extern void reverse(string &);

#endif
